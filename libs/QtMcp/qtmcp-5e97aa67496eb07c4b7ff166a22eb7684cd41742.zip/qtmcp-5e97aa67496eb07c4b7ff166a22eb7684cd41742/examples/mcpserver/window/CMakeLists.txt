# Copyright (C) 2025 Signal Slot Inc.
# SPDX-License-Identifier: BSD-3-Clause

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

qt_add_executable(window
    main.cpp
    tools.h tools.cpp
)

target_link_libraries(window PRIVATE
    Qt::McpServer
    Qt::Gui
)

if(NOT DEFINED INSTALL_EXAMPLESDIR)
    set(INSTALL_EXAMPLESDIR "examples")
endif()

install(TARGETS window
    RUNTIME DESTINATION "${INSTALL_EXAMPLESDIR}/mcpserver/window"
    BUNDLE DESTINATION "${INSTALL_EXAMPLESDIR}/mcpserver/window"
    LIBRARY DESTINATION "${INSTALL_EXAMPLESDIR}/mcpserver/window"
)
