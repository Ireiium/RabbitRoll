// Copyright (C) 2025 Signal Slot Inc.
// SPDX-License-Identifier: LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only

#ifndef QMCPBLOBRESOURCECONTENTS_H
#define QMCPBLOBRESOURCECONTENTS_H

#include <QtCore/QByteArray>
#include <QtCore/QJsonObject>
#include <QtCore/QString>
#include <QtCore/QUrl>
#include <QtMcpCommon/qmcpgadget.h>
#include <QtMcpCommon/qmcpresource.h>

QT_BEGIN_NAMESPACE

/*! \class QMcpBlobResourceContents
    \inmodule QtMcpCommon
*/
class Q_MCPCOMMON_EXPORT QMcpBlobResourceContents : public QMcpGadget
{
    Q_GADGET

    /*!
        \property QMcpBlobResourceContents::_meta
        \brief Reserved by MCP to allow clients and servers to attach additional metadata.
        \since MCP 2025-06-18
    */
    Q_PROPERTY(QJsonObject _meta READ meta WRITE setMeta)

    /*!
        \property QMcpBlobResourceContents::blob
        \brief A base64-encoded string representing the binary data of the item.
    */
    Q_PROPERTY(QByteArray blob READ blob WRITE setBlob REQUIRED)

    /*!
        \property QMcpBlobResourceContents::mimeType
        \brief The MIME type of this resource, if known.
    */
    Q_PROPERTY(QString mimeType READ mimeType WRITE setMimeType)

    /*!
        \property QMcpBlobResourceContents::uri
        \brief The URI of this resource.
    */
    Q_PROPERTY(QUrl uri READ uri WRITE setUri REQUIRED)

    Q_PROPERTY(QString name READ name WRITE setName)

public:
    QMcpBlobResourceContents() : QMcpGadget(new Private) {}
    QMcpBlobResourceContents(const QMcpResource &resource, const QByteArray &blob)
        : QMcpGadget(new Private)
    {
        d<Private>()->mimeType = resource.mimeType();
        d<Private>()->blob = blob;
        d<Private>()->uri = resource.uri();
        d<Private>()->name = resource.name();
    }

    QJsonObject meta() const {
        return d<Private>()->_meta;
    }

    void setMeta(const QJsonObject &meta) {
        if (this->meta() == meta) return;
        d<Private>()->_meta = meta;
    }

    QByteArray blob() const {
        return d<Private>()->blob;
    }

    void setBlob(const QByteArray &blob) {
        if (this->blob() == blob) return;
        d<Private>()->blob = blob;
    }

    QString mimeType() const {
        return d<Private>()->mimeType;
    }

    void setMimeType(const QString &mimeType) {
        if (this->mimeType() == mimeType) return;
        d<Private>()->mimeType = mimeType;
    }

    QUrl uri() const {
        return d<Private>()->uri;
    }

    void setUri(const QUrl &uri) {
        if (this->uri() == uri) return;
        d<Private>()->uri = uri;
    }

    QString name() const {
        return d<Private>()->name;
    }

    void setName(const QString &name) {
        if (this->name() == name) return;
        d<Private>()->name = name;
    }

    const QMetaObject* metaObject() const override {
        return &staticMetaObject;
    }

protected:
    bool isPropertyAvailable(QByteArrayView name, QtMcp::ProtocolVersion protocolVersion) const override {
        if (name == "_meta")
            return protocolVersion >= QtMcp::ProtocolVersion::v2025_06_18;
        return QMcpGadget::isPropertyAvailable(name, protocolVersion);
    }

private:
    struct Private : public QMcpGadget::Private {
    public:
        QJsonObject _meta;
        QByteArray blob;
        QString mimeType;
        QUrl uri;
        QString name;

        Private *clone() const override { return new Private(*this); }
    };
};

Q_DECLARE_SHARED(QMcpBlobResourceContents)

QT_END_NAMESPACE

#endif // QMCPBLOBRESOURCECONTENTS_H
