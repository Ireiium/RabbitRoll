# Copyright (C) 2025 Signal Slot Inc.
# SPDX-License-Identifier: LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only

add_subdirectory(stdio)
if(TARGET Qt6::Network)
    add_subdirectory(sse)
    add_subdirectory(streamablehttp)
endif()
